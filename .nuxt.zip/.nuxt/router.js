import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _2277193e = () => interopDefault(import('..\\pages\\order\\index.vue' /* webpackChunkName: "pages/order/index" */))
const _5bd9fca7 = () => interopDefault(import('..\\pages\\patient\\index.vue' /* webpackChunkName: "pages/patient/index" */))
const _7645e465 = () => interopDefault(import('..\\pages\\product.vue' /* webpackChunkName: "pages/product" */))
const _7adbbc9b = () => interopDefault(import('..\\pages\\toPDFTemplate\\index.vue' /* webpackChunkName: "pages/toPDFTemplate/index" */))
const _aaab18c6 = () => interopDefault(import('..\\pages\\user\\index.vue' /* webpackChunkName: "pages/user/index" */))
const _44ea849a = () => interopDefault(import('..\\pages\\hosp\\detail\\index.vue' /* webpackChunkName: "pages/hosp/detail/index" */))
const _e962b47e = () => interopDefault(import('..\\pages\\order\\show.vue' /* webpackChunkName: "pages/order/show" */))
const _68813836 = () => interopDefault(import('..\\pages\\patient\\add.vue' /* webpackChunkName: "pages/patient/add" */))
const _40859d90 = () => interopDefault(import('..\\pages\\patient\\show.vue' /* webpackChunkName: "pages/patient/show" */))
const _6745a290 = () => interopDefault(import('..\\pages\\user\\account.vue' /* webpackChunkName: "pages/user/account" */))
const _116e5216 = () => interopDefault(import('..\\pages\\user\\insured.vue' /* webpackChunkName: "pages/user/insured" */))
const _3513f29d = () => interopDefault(import('..\\pages\\user\\notice.vue' /* webpackChunkName: "pages/user/notice" */))
const _791597ce = () => interopDefault(import('..\\pages\\user\\order.vue' /* webpackChunkName: "pages/user/order" */))
const _38373d94 = () => interopDefault(import('..\\pages\\user\\shiming.vue' /* webpackChunkName: "pages/user/shiming" */))
const _3dc8908f = () => interopDefault(import('..\\pages\\user\\suggest.vue' /* webpackChunkName: "pages/user/suggest" */))
const _b78d8fbe = () => interopDefault(import('..\\pages\\weixin\\callback.vue' /* webpackChunkName: "pages/weixin/callback" */))
const _71ec1daf = () => interopDefault(import('..\\pages\\hosp\\buyFlow\\step1.vue' /* webpackChunkName: "pages/hosp/buyFlow/step1" */))
const _71fa3530 = () => interopDefault(import('..\\pages\\hosp\\buyFlow\\step2.vue' /* webpackChunkName: "pages/hosp/buyFlow/step2" */))
const _72084cb1 = () => interopDefault(import('..\\pages\\hosp\\buyFlow\\step3.vue' /* webpackChunkName: "pages/hosp/buyFlow/step3" */))
const _72166432 = () => interopDefault(import('..\\pages\\hosp\\buyFlow\\step4.vue' /* webpackChunkName: "pages/hosp/buyFlow/step4" */))
const _6c200840 = () => interopDefault(import('..\\pages\\hosp\\detail\\detail.vue' /* webpackChunkName: "pages/hosp/detail/detail" */))
const _8db71b28 = () => interopDefault(import('..\\pages\\hosp\\detail\\toBuy.vue' /* webpackChunkName: "pages/hosp/detail/toBuy" */))
const _d30bd370 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))
const _eb957a20 = () => interopDefault(import('..\\pages\\hosp\\notice\\_hoscode.vue' /* webpackChunkName: "pages/hosp/notice/_hoscode" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/order",
    component: _2277193e,
    name: "order"
  }, {
    path: "/patient",
    component: _5bd9fca7,
    name: "patient"
  }, {
    path: "/product",
    component: _7645e465,
    name: "product"
  }, {
    path: "/toPDFTemplate",
    component: _7adbbc9b,
    name: "toPDFTemplate"
  }, {
    path: "/user",
    component: _aaab18c6,
    name: "user"
  }, {
    path: "/hosp/detail",
    component: _44ea849a,
    name: "hosp-detail"
  }, {
    path: "/order/show",
    component: _e962b47e,
    name: "order-show"
  }, {
    path: "/patient/add",
    component: _68813836,
    name: "patient-add"
  }, {
    path: "/patient/show",
    component: _40859d90,
    name: "patient-show"
  }, {
    path: "/user/account",
    component: _6745a290,
    name: "user-account"
  }, {
    path: "/user/insured",
    component: _116e5216,
    name: "user-insured"
  }, {
    path: "/user/notice",
    component: _3513f29d,
    name: "user-notice"
  }, {
    path: "/user/order",
    component: _791597ce,
    name: "user-order"
  }, {
    path: "/user/shiming",
    component: _38373d94,
    name: "user-shiming"
  }, {
    path: "/user/suggest",
    component: _3dc8908f,
    name: "user-suggest"
  }, {
    path: "/weixin/callback",
    component: _b78d8fbe,
    name: "weixin-callback"
  }, {
    path: "/hosp/buyFlow/step1",
    component: _71ec1daf,
    name: "hosp-buyFlow-step1"
  }, {
    path: "/hosp/buyFlow/step2",
    component: _71fa3530,
    name: "hosp-buyFlow-step2"
  }, {
    path: "/hosp/buyFlow/step3",
    component: _72084cb1,
    name: "hosp-buyFlow-step3"
  }, {
    path: "/hosp/buyFlow/step4",
    component: _72166432,
    name: "hosp-buyFlow-step4"
  }, {
    path: "/hosp/detail/detail",
    component: _6c200840,
    name: "hosp-detail-detail"
  }, {
    path: "/hosp/detail/toBuy",
    component: _8db71b28,
    name: "hosp-detail-toBuy"
  }, {
    path: "/",
    component: _d30bd370,
    name: "index"
  }, {
    path: "/hosp/notice/:hoscode?",
    component: _eb957a20,
    name: "hosp-notice-hoscode"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
